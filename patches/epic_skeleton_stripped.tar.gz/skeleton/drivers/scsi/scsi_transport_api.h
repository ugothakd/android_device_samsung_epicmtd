#ifndef _SCSI_TRANSPORT_API_H
#define _SCSI_TRANSPORT_API_H

void scsi_schedule_eh(struct Scsi_Host *shost);

#endif /* _SCSI_TRANSPORT_API_H */
