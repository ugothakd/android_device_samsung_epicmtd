#ifndef _CTL_FUNCS_H
#define _CTL_FUNCS_H

ULONG ModemUpNotiMsg(PUCHAR Buffer);
ULONG ModemResetMsg(PUCHAR Buffer);

#endif
