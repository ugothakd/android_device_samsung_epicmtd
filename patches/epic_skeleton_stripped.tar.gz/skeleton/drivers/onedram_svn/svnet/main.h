/*add interface for sipc files*/

void _non_fmt_wakelock_timeout(void);

void _fmt_wakelock_timeout(void);


