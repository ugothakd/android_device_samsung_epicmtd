#ifndef _Si4709_MAIN_H
#define _Si4709_MAIN_H

#include <linux/wait.h>

extern wait_queue_head_t Si4709_waitq;

#endif

