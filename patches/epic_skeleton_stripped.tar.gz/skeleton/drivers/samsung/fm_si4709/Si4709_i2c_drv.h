#ifndef _Si4709_I2C_DRV_H
#define _Si4709_I2C_DRV_H

extern int Si4709_i2c_drv_init(void);
extern int Si4709_i2c_drv_exit(void);

#endif

